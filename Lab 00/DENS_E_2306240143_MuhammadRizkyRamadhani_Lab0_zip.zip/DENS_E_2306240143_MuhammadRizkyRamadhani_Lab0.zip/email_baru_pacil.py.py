#Cetak judul program ini
print("Buat Email Baru Khusus Anak Pacil")

#Melakukan input untuk info yang akan digunakan dalam pembuatan email
nama_depan = input("Nama Depan: ")
nama_panggilan = input("Nama Panggilan: ")
tanggal_lahir = input("Tanggal Lahir: ")

#Mencetak ucapan selamat datang sesuai nama yang di input
print("Halo " + nama_depan + ", Selamat datang di Fasilkom!")

#Mencetak email baru untuk anak pacil
print("Email kamu adalah " + nama_depan + "." + nama_panggilan + tanggal_lahir + "@ui.ac.id")