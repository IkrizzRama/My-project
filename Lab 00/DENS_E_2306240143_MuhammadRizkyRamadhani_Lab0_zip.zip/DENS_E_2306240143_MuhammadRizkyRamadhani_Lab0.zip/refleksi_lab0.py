#Mencetak judul dari program ini
print("Perkenalan diri anak pacil baru")

#Melakukan input untuk mendapatkan informasi yang dibutuhkan
nama_pacil = input("Masukkan nama kamu: ")
asal_jurusan = input("Masukkan jurusan kamu: ")
tanggal_lahir = input("Masukkan tanggal lahir kamu: ")
asal_kota = input("Masukkan asal kota kamu: ")
asal_sekolah = input("Masukkan asal sekolah kamu: ")
motto_hidup = input("Masukkan motto hidup kamu: ")

#Pembatas untuk membuat output terlihat lebih rapih
print("------------------------------------------")

#Mencetak ucapan perkenalan diri berdasarkan data yang telah diinput
print ("Halo " + nama_pacil + " dari Jurusan " + asal_jurusan +" lahir pada " + tanggal_lahir)
print ("Berasal dari " + asal_kota + " dan asal sekolah " + asal_sekolah)
print ("Memiliki motto hidup " + motto_hidup)
print ("Selamat bergabung di keluarga Fasilkom!")
